#include <stdio.h>
#include <string.h>
#include <time.h>
#include <stdlib.h>


void OpenFileAndAdd(void);
void SearchFile(void);
void Scanner(void);
void ClearFileContents(void);

int main()
{
	int choice=0;
	
	system("cls");
	printf("\n THANK YOU FOR USING THIS SOFTWARE ");
	for(;;)
	{
			
		printf("\n\nWhat do u want to do?");
		printf("\n1. Add Event ?");
		printf("\n2. Clear the list ?");
		printf("\n3. Check for a event? ");
		printf("\n4. Exit ?\n");
		printf("Enter choice:");
		
		scanf("%d",&choice);

		switch(choice)
		{
		case 1:
			OpenFileAndAdd();
			break;
		case 2:
			ClearFileContents();
			break;
		case 3:
			SearchFile();
			//Scanner();
				break;
		case 4:
			exit(0);
			break;
		}


	}
	
}


void OpenFileAndAdd(void)
{
	int n;
	FILE *bd;
	char *name[45],*specialevent[45],*bday[10];
	int bday1;
	
	printf("\nAdding an Event...\n");
	printf("Enter the name:");
	scanf("%s",name);
	printf("Enter the event name:");
	scanf("%s",specialevent);
	printf("Enter the birthday(ddmmyyyy):");
	scanf("%s",bday);
	
	bd=fopen("c:\\Temp\\Event.txt","a");
	fprintf(bd,"%s  %s\n%s\n\n",name,specialevent,bday);
	fclose(bd);
	printf("...Added...");
	
}




void SearchFile(void)
{
	int i=1,flag=0,count=1;
	FILE *bd;
	char name[90],date[10],input[5];
	char *c=NULL;
		
	bd = fopen("c:\\Temp\\Event.txt","r");
	if(bd==NULL)
	{
		printf("Data file not found !! \n");
		exit(0);
	}
	printf("Enter the date:(ddmm):");
	scanf("%s",input);
	printf("\nList of people with their special Events falling on %s :",input);
	do 
	{
		if(i%2!=0)
		c = fgets(name,100,bd);
		if(i%2==0)
		{
			c=fgets(date,5,bd);
			if(!strcmp(input,date))
			{
				flag=1;
				printf("\n\n%d. %s",count,name);
				count++;
			}
		}
		i++;
	}while (c != NULL);
	
	if(!flag)
		printf("\nNONE!");
	fclose(bd);

	
	
}


/*

void Scanner(void)
{
	int i=1,flag=0,count=1;
	FILE *bd;
	char name[50],date[10],input[5];
	char *c;
	char buffer1[5]={0};
	char buffer2[3]={0};
	char buffer3[5]={0};
	

	time_t now = time(NULL);
	struct tm *t = localtime(&now);

	char temp1='0';
	char temp2='0';
	char temp3='0';
	char temp4='0';

	int len;

	itoa(t->tm_mday,buffer1,10);
	itoa(t->tm_mon+1,buffer2,10);

	strcat(buffer1,buffer2);
	len=strlen(buffer1);
	
	if (len==3)
	{
		buffer1[4]=buffer1[3];
		buffer1[3]=buffer1[2];
		buffer1[2]=buffer1[1];
		buffer1[1]=buffer1[0];
		buffer1[0]='0';

	}

	bd = fopen("Event.txt","r");
	printf("Enter the date:(ddmm):");
	scanf("%s",input);
	printf("\nList of people with their birthday falling on %s :",input);
	do 
	{
		if(i%2!=0)
		c = fgets(name,50,bd);
		
		if(i%2==0)
		{
			c=fgets(date,5,bd);
			if(!strcmp(input,date))
			{
				flag=1;printf("\a\n\n%d. %s",count,name);count++;
			}
		}
		i++;
	}while (c != NULL);
	
	if(!flag)
		printf("\nNONE!");
	fclose(bd);
}
*/


void ClearFileContents(void)
{
	int n1,n2;
	FILE *cl;
	
	printf("\a\a\a\n WARNING! YOU ARE ABOUT TO CLEAR THE LIST! PROCEED?\n1. Yes\n2. No (Go to main menu)\nEnter choice:");
	scanf("%d",&n1);
	if(n1==1)
	{
			cl=fopen("c:\\Temp\\Event.txt","w");
			fclose(cl);
			printf("\n\a Data Erased!!");
	}
	if(n1==2)
	{
		return;

	}

}