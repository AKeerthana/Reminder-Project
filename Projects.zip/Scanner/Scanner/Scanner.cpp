// Scanner.cpp : Defines the entry point for the console application.
//
#include <stdio.h>
#include <string.h>
#include <time.h>
#include <stdlib.h>

void Scanner(void);

int main()
{

	char c='0';
	Scanner();
	for(;;)
	{
		printf("\n\n Press X to exit");
		scanf("%c",&c);

		if(c=='x' || c=='X')
		{
			exit(0);
		}
	}
	


}

void Scanner(void)
{
	int i=1,flag=0,count=1;
	FILE *bd;
	char name[50]={0};
	char date[10]={0};
	char input[5]={0};
	char *c=NULL;
	char buffer1[5]={0};
	char buffer2[3]={0};
	char buffer3[5]={0};
	

	time_t now = time(NULL);
	struct tm *t = localtime(&now);

	char temp1='0';
	char temp2='0';
	char temp3='0';
	char temp4='0';

	int len;

	itoa(t->tm_mday,buffer1,10);
	itoa(t->tm_mon+1,buffer2,10);

	strcat(buffer1,buffer2);
	len=strlen(buffer1);
	
	if (len==3)
	{
		buffer1[4]=buffer1[3];
		buffer1[3]=buffer1[2];
		buffer1[2]=buffer1[1];
		buffer1[1]=buffer1[0];
		buffer1[0]='0';

	}

	bd = fopen("C:\\temp\\Event.txt","r");
//	printf("Enter the date:(ddmm):");
//	scanf("%s",input);
//  printf("\nList of people with their birthday falling on %s :",input);
	do 
	{
		if(i%2!=0)
		c = fgets(name,50,bd);
		
		if(i%2==0)
		{
			c=fgets(date,5,bd);
			if(!strcmp(buffer1,date))
			{
				flag=1;printf("\a\n\n%d. %s",count,name);count++;
			}
		}
		i++;
	}while (c != NULL);
	
	if(!flag)
		printf("\nNONE!");
	fclose(bd);
}
